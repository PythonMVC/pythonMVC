from . import main

main()

